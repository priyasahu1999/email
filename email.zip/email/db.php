<?php

$conn = mysqli_connect('localhost','a1658qvj_medigent','Medigent@2022','a1658qvj_medigent');

?>