<?php

die();

extract($_POST);
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'db.php';

if(isset($_POST['submit'])){
	$name = mysqli_real_escape_string($conn,$_POST['name']);
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$subject = mysqli_real_escape_string($conn,$_POST['subject']);
    $insertquery = "INSERT INTO `email`(`name`,`email`,`subject`) VALUES ('$name','$email','$subject')";

			$iquery = mysqli_query($conn, $insertquery);
			if($iquery){
			    $mail = new PHPMailer(true);

                try {
                    //Server settings
                    // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                    $mail->isSMTP();                                            //Send using SMTP
                    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                    $mail->Username   = 'priyanka.6september1999@gmail.com';                     //SMTP username
                    $mail->Password   = 'dvmqqgbwdqvcrtfl';                               //SMTP password
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
                
                    //Recipients
                    $mail->setFrom('priyanka.6september1999@gmail.com', 'priyanka');
                    $mail->addAddress($email, $name);     //Add a recipient
                
                    //Attachments
                    // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
                    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name
                
                    //Content
                    $mail->isHTML(true);                                  //Set email format to HTML
                    $mail->Subject = 'registration';
                    $mail->Body    = 'Thank you for your registration';
                
                
                    $mail->send();
                    echo 'Message has been sent';
                } catch (Exception $e) {
                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                }
			 //   header("Location: login.php");
					?>
						<script>
								alert('Registration successful');
								// window.location.href = 'login';
								//
							</script>
					<?php

			}else{
			    echo mysqli_error($conn);
					?>
						 <script>
								 alert("Something went wrong,try again");
						 </script>
					<?php
			}
}
//Create an instance; passing `true` enables exceptions
?>